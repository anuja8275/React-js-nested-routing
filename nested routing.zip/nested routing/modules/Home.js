import React from 'react'

export default React.createClass({
  render() {
    return <div  className="borderreds page-content-wrapper">Home</div>
  }
})
